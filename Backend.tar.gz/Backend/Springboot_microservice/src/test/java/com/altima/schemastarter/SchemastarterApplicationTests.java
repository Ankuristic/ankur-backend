package com.altima.schemastarter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchemastarterApplicationTests {

	@Test
	void contextLoads() {
	}

}
