// package com.altima.schemastarter.Controller;


// import java.util.List;

// import org.springframework.http.HttpStatus;
// import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.*;

// import com.altima.schemastarter.Entity.Organization;
// import com.altima.schemastarter.service.OrganizationService;

// import lombok.RequiredArgsConstructor;

// @RestController
// @RequestMapping("/api/organizations")
// // @RequiredArgsConstructor
// public class OrganizationController {

//     private final OrganizationService organizationService;

//     @PostMapping
//     public ResponseEntity<Organization> create(@RequestBody Organization organization) {
//         return new ResponseEntity<>(
//                 organizationService.createOrganization(organization),
//                 HttpStatus.CREATED
//         );
//     }

//     @GetMapping("/{id}")
//     public ResponseEntity<Organization> getById(@PathVariable Long id) {
//         return ResponseEntity.ok(
//                 organizationService.getOrganizationById(id)
//         );
//     }

//     @GetMapping
//     public ResponseEntity<List<Organization>> getAll() {
//         return ResponseEntity.ok(
//                 organizationService.getAllOrganizations()
//         );
//     }

//     @PutMapping("/{id}")
//     public ResponseEntity<Organization> update(
//             @PathVariable Long id,
//             @RequestBody Organization organization) {

//         return ResponseEntity.ok(
//                 organizationService.updateOrganization(id, organization)
//         );
//     }

//     @DeleteMapping("/{id}")
//     public ResponseEntity<Void> delete(@PathVariable Long id) {
//         organizationService.deleteOrganization(id);
//         return ResponseEntity.noContent().build();
//     }
// }

    

