// package com.altima.schemastarter.dto;

// public class ResetPasswordDto {
    
// }
