// @Entity
// @Table(name = "users")
// public class Employee {

//     @Id
//     @GeneratedValue(strategy = GenerationType.IDENTITY)
//     private Long id;

//     private String name;
//     private String email;

//     @ManyToOne
//     private Organization organization;

//     @ManyToOne
//     private Department department;

//     @ManyToOne
//     private SubDepartment subDepartment;

//     @ManyToOne
//     private Role role;
// }
