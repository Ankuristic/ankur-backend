package com.altima.schemastarter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchemastarterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchemastarterApplication.class, args);
	}

}
