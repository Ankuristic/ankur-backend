package com.altima.schemastarter.dto;

import javax.validation.constraints.NotBlank;


public class LoginDto {

    private String email;   // optional

    @javax.validation.constraints.NotBlank(message = "Password is required")
    private String password;

    // getters & setters


public String getEmail() {
        return email;
    }

    // Setter for email
    public void setEmail(String email) {
        this.email = email;
    }

    // Getter for password
    public String getPassword() {
        return password;
    }

    // Setter for password
    public void setPassword(String password) {
        this.password = password;
    }
}





