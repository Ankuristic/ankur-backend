package com.altima.schemastarter.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.altima.schemastarter.Entity.Organization;
import com.altima.schemastarter.repository.OrganizationRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class OrganizationService {

    private final OrganizationRepository organizationRepository;

    // CREATE
    public Organization createOrganization(Organization organization) {

        if (organizationRepository.existsByCode(organization.getCode())) {
            throw new RuntimeException("Organization code already exists");
        }

        return organizationRepository.save(organization);
    }

    // READ by ID
    public Organization getOrganizationById(Long id) {
        return organizationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Organization not found"));
    }

    // READ all
    public List<Organization> getAllOrganizations() {
        return organizationRepository.findAll();
    }

    // UPDATE
    public Organization updateOrganization(Long id, Organization organization) {

        Organization existing = organizationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Organization not found"));

        existing.setName(organization.getName());
        existing.setStatus(organization.getStatus());

        return organizationRepository.save(existing);
    }

    // DELETE
    public void deleteOrganization(Long id) {

        if (!organizationRepository.existsById(id)) {
            throw new RuntimeException("Organization not found");
        }

        organizationRepository.deleteById(id);
    }
}

