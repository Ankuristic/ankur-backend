package com.altima.schemastarter.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.altima.schemastarter.Entity.Organization;

public interface OrganizationRepository  extends JpaRepository<Organization, Long> {

        boolean existsByCode(String code);


}

