package com.altima.schemastarter.Entity;

public enum Status {

}
