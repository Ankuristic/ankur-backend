package com.altima.schemastarter.Controller;

import org.springframework.web.bind.annotation.RestController;

import com.altima.schemastarter.dto.LoginDto;
import com.altima.schemastarter.security.JwtUtil;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
// import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
// import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestParam;



@RestController
public class AdminController {


// @GetMapping("/admin/dashboard")
// public String adminDashboard() {
//     return "Welcome Super Admin!";
// }


// @GetMapping("/admin/login")
//     public ResponseEntity<String> adminDashboard() {
//         return ResponseEntity
//                 .status(HttpStatus.OK)   // 200
//                 .body("Welcome Super Admin!");
//     }
// }






    // Inject properties safely
    // @Value("${superadmin.email}")
    // private String superadminEmail;

    // @Value("${superadmin.password}")
    // private String superadminPassword;


// @PostMapping("/admin/login")
//     public ResponseEntity<String> adminLogin(@Valid @RequestBody LoginDto loginDto) {


//         // Check email
//         if (!loginDto.getEmail().equals(superadminEmail)) {
//             return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found!");
//         }

//         // Check password
//         if (!loginDto.getPassword().equals(superadminPassword)) {
//             return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid password!");
//         }

//         // Success
//         return ResponseEntity.ok("Welcome Super Admin!");
//     }
// }


    
//  @GetMapping("/verify-email")
//     public LoginDto verifyEmail(@RequestParam String token) {

//         if (!token.equals("SYSTEM_SETUP_TOKEN")) {
//             throw new RuntimeException("INVALID_TOKEN");
//         }

//         props.setEmailVerified(true);
//         return new ApiResponse("Email verified successfully");
//     }



// @GetMapping("/email-status")
//     public Map<String, Object> emailStatus() {
//         return Map.of(
//                 "email", props.getEmail(),
//                 "verified", props.isEmailVerified()
//         );
//     }


//Forgot Password

//  @PostMapping("/forgot-password")
//     public ApiResponse forgotPassword() {

//         resetToken = UUID.randomUUID().toString();

//         // simulate email
//         System.out.println(
//             "Reset link: http://localhost:8080/api/auth/superadmin/reset-password?token="
//             + resetToken
//         );

//         return new ApiResponse("Password reset link sent");
//     }

// Reset Password

// @PostMapping("/admin/reset-password")
// public ResponseEntity<?> resetPassword(
//         @Valid @RequestBody ResetPasswordDto dto) {

//     Claims claims;

//     try {
//         claims = jwtUtil.parseToken(dto.getToken());
//     } catch (Exception e) {
//         return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
//                 .body("Invalid or expired token");
//     }

//     if (!"RESET".equals(claims.get("type"))) {
//         return ResponseEntity.badRequest()
//                 .body("Invalid reset token");
//     }

//     String email = claims.getSubject();

//     if (!email.equals(superadminEmail)) {
//         return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
//                 .body("Invalid admin");
//     }

//     // Update password
//     superadminPassword = dto.getNewPassword();

//     return ResponseEntity.ok("Password reset successful");
// }




    @Value("${superadmin.email}")
    private String superAdminEmail;

    @Value("${superadmin.password}")
    private String superAdminPassword;

    private final JwtUtil jwtUtil;

    public AdminController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/admin/login")
    public ResponseEntity<?> login(@Valid @RequestBody LoginDto loginDto) {

        // password mandatory
        if (loginDto.getPassword() == null || loginDto.getPassword().isBlank()) {
            return ResponseEntity
                    .status(HttpStatus.BAD_REQUEST)
                    .body("Password is required");
        }

        // email optional
        if (loginDto.getEmail() != null &&
            !loginDto.getEmail().equals(superAdminEmail)) {
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("User not found");
        }

        if (!loginDto.getPassword().equals(superAdminPassword)) {
            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body("Invalid password");
        }

        String token = jwtUtil.generateToken(
                loginDto.getEmail() != null ? loginDto.getEmail() : "SUPER_ADMIN"
        );

        return ResponseEntity.ok(token);
    }
}
