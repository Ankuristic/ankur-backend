package com.altima.schemastarter.Controller;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
public class Hello {

    @GetMapping("/Test")
    public String getMethodName(@RequestParam String param) {
        return new String("Hello App under development");
    }
    


    
}
