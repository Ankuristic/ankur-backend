package com.altima.schemastarter.Entity;

public class Policy {
    
}
