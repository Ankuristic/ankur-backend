package com.altima.schemastarter.config;

public class InMemoryUserDetailsManager {

}
