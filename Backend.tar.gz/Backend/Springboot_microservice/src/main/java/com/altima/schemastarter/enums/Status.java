package com.altima.schemastarter.enums;

public enum Status {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}


// public enum  Environment {

//     Staging,
// Development,

// }