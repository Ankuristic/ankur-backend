// import "./Login.css";
// import LoginCard from "../../components/LoginCard/LoginCard";
// // import logo2 from "../../Assests/images/logo2";
// import  logo from "../../Assests/images/Logo";

// const Login = () => {
//   return (
//     <div className="login-page">
//       <div className="login-left">
//         {/* <img src={logo2} alt="ERP Logo" /> */}
//         {/* <img src= {logo} alt = "Lotus ERP Logo"/> */}
//         <h1> Lotus ERP Logo </h1>
//         <h1> Copyrights c Lotus ERP Suite.2026 </h1>
//       </div>

//       <LoginCard />
//     </div>
//   );
// };

// export default Login;


import "./Login.css";
import LoginCard from "../../components/LoginCard/LoginCard";
import altimaLogo from "../../../../../Frontend/frontend/src/assest/images/logo.png"; 

const Login = ({ setIsLoggedIn }) => {
  return (
    <div className="login-page">
      {/* LEFT SIDE */}
      <div className="login-left">
        <img
          src={altimaLogo}
          alt="Altima Solutions"
          className="altima-logo"
        />

        <h1 className="lotus-title">Lotus ERP Suite</h1>

        <p className="copyright">
      Copyrights © 2026 Lotus ERP Suite.2026
        </p>
      </div>

      {/* RIGHT SIDE */}
      {/* <LoginCard /> */}

       <LoginCard setIsLoggedIn={setIsLoggedIn} />
    </div>
  );
};

export default Login;





// import "./Login.css";
// import LoginCard from "../../components/LoginCard/LoginCard";

// const Login = () => {
//   return (
//     <div className="login-page">
//       <div className="login-left">
//         <img src="/images/logo.png" alt="ERP Logo" />
//         <h1>ERP Suite</h1>
//       </div>

//       <LoginCard />
//     </div>
//   );
// };

// export default Login;

