// import "./Dashboard.css";
// import Sidebar from "../../components/Sidebar/Sidebar";
// import Topbar from "../../components/DashboardCard/DashboardCards"
// import DashboardCard from "../../components/TopBar/TobBar";

// const Dashboard = () => {
//   return (
//     <div className="dashboard">
//       <Sidebar />

//       <div className="dashboard-content">
//         <Topbar />

//         <div className="cards-container">
//           <DashboardCard title="Schema" />
//           <DashboardCard title="Users & Roles" />
//           <DashboardCard title="Domains & Modules" />
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dashboard;


import { useNavigate } from "react-router-dom";
import Sidebar from "../../components/Sidebar/Sidebar";
import Header from "../../components/Header /Header";
import ActionCard from "../../components/Card/ActionCard";
import "./Dashboard.css";

const Dashboard = () => {
  const navigate = useNavigate();

  return (
    <div className="dashboard-layout">
      <Sidebar />

      <div className="dashboard-main">
        <Header title="Good Morning Sunil !" subtitle="Super Admin" />

        <div className="card-row">
          <ActionCard title="Schema" onClick={() => navigate("/schema")} />
          <ActionCard title="Users & Roles" />
          <ActionCard title="Domains & Modules" />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
