import Sidebar from "../../components/Sidebar/Sidebar";
import Header from "../../components/Header /Header";
import ActionCard from "../../components/Card/ActionCard";
import "./Schema.css";

const Schema = () => {
  return (
    <div className="schema-layout">
      <Sidebar />

      <div className="schema-main">
        <Header title="Schema" />

        <div className="schema-cards">
          <ActionCard title="Schema List" />
          <ActionCard title="Create Schema" />
          <ActionCard title="Schema Overview" />
          <ActionCard title="Edit / Disable / Delete" />
        </div>
      </div>
    </div>
  );
};

export default Schema;
