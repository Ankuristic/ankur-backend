import "./SuperAdminDisabled.css";
import { FiAlertCircle } from "react-icons/fi";

const SuperAdminDisabled = ({ onBackToLogin }) => {
  return (
    <div className="disabled-container">
      <div className="disabled-card">
        <div className="icon-wrapper">
          <FiAlertCircle size={36} />
        </div>

        <p className="disabled-text">
          Your super admin account is disabled. Contact <br />
          system administrator.
        </p>

        <button className="back-btn" onClick={onBackToLogin}>
          Back to Login
        </button>
      </div>
    </div>
  );
};

export default SuperAdminDisabled;
