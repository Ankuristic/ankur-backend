import "./Header.css";

const Header = ({ title, subtitle }) => {
  return (
    <div className="header">
      <div>
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>

      <input className="search" placeholder="Search" />
    </div>
  );
};

export default Header;
