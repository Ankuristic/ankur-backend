// export default function Sidebar() {
//   return (
//     <aside className="sidebar">
//       <h2 className="logo">ALTIMA</h2>

//       <ul className="menu">
//         <li className="active">Dashboard</li>
//         <li>Permissions</li>
//         <li>Security & Audit</li>
//         <li>Integration</li>
//         <li>Settings</li>
//       </ul>
//     </aside>
//   );
// }


import "./Sidebar.css";

const Sidebar = () => {
  return (
    <div className="sidebar">
      <div className="logo">ALTIMA</div>

      <ul>
        <li>Dashboard</li>
        <li className="active">Schema</li>
        <li>Permissions</li>
        <li>Security & Audit</li>
        <li>Integration</li>
        <li>Settings</li>
      </ul>
    </div>
  );
};

export default Sidebar;
