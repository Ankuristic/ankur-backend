// import "./Input.css";

// const Input = ({ type, placeholder }) => {
//   return (
//     <div className="input-wrapper">
//       <input type={type} placeholder={placeholder} />
//     </div>
//   );
// };

// export default Input;


import "./Input.css";

const Input = ({ type, placeholder, value, onChange, icon }) => {
  return (
    <div className="input-wrapper">
      <span className="input-icon">{icon}</span>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        autoComplete="off"
        required
      />
    </div>
  );
};

export default Input;

