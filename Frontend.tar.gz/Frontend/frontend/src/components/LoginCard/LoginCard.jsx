// import "./LoginCard.css";
// import Input from "../Input/Input";
// import Button from "../Button/Button";

// const LoginCard = () => {
//   return (
//     <div className="login-card">
//       <h2>Welcome</h2>
//       <p>Secure access for system administrators</p>

//       <Input type="text" placeholder="User Name" />
//       <Input type="password" placeholder="Password" />

//       <a href="#" className="forgot-link">Forgot Password</a>

//       <Button text="Log in" />
//     </div>
//   );
// };

// export default LoginCard;



import { useState } from "react";
import "./LoginCard.css";
import Input from "../Input/Input";
import Button from "../Button/Button";

const LoginCard = ({ setIsLoggedIn }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success,setSuccess] = useState("");

  const handleLogin = async () => {
            console.log("LOGIN BUTTON CLICKED");

    
    setError("");

    try {
      const basicAuth = btoa(`${username}:${password}`);

      const response = await fetch(
        "http://localhost:8080/admin/login",
        {
          method: "GET",
          headers: {
            Authorization: `Basic ${basicAuth}`,
          },
        }
      );

      // if (!response.ok) {
      //   throw new Error("Invalid credentials");
      // }

      if (response.status === 401) {
      setError("Invalid email or password");
      return;
    }

    if (response.status === 403) {
      setError("You are not authorized");
      return;
    }

    if (!response.ok) {
      setError("Something went wrong");
      return;
    }



      //login success
  //     localStorage.setItem("isSuperAdmin", "true");
  //     localStorage.setItem("basicAuth", basicAuth); // optional
  //     setIsLoggedIn(true);
  //   } catch (err) {
  //     setError("server not reachable");
  //   }
  // };

  // if (response.status === 200) {
  //       setSuccess("Login successful");

  //       localStorage.setItem("isSuperAdmin", "true");
  //       localStorage.setItem("basicAuth", basicAuth);

  //       setIsLoggedIn(true);
  //     }

  //   } catch (err) {
  //     setError("Server not reachable");
  //   }
  // };

  // success
      setSuccess("Login successful");

      localStorage.setItem("isSuperAdmin", "true");
      localStorage.setItem("basicAuth", basicAuth);

      // Delay so user can SEE success
      setTimeout(() => {
        setIsLoggedIn(true);
      }, 800);

    } catch (err) {
      setError("Server not reachable");
    }
  };

  return (
    <div className="login-card">
      <h2>Welcome</h2>
      <p>Secure access for system administrators</p>

      {error && <p className="error">{error}</p>}

      <Input
        type="text"
        placeholder="Super Admin Email"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />

      <Input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

<a href="#" className="forgot-password">
  Forgot Password
</a>

{/* Remember device */}
<label className="remember-device">
  <input type="checkbox" />
  Remember this device
</label>

      <Button text="Log in" onClick={handleLogin} />
      {/* <h2> Forgot Password</h2>
      <h2></h2> */}
    </div>
  );
};

export default LoginCard;
