import "./TopBar.css";

const Topbar = () => {
  return (
    <div className="topbar">
      <div>
        <h2>Good Morning Sunil!</h2>
        <p>Super Admin</p>
      </div>

      <input
        type="text"
        placeholder="Search"
        className="search-input"
      />
    </div>
  );
};

export default Topbar;
