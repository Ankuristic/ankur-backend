// import "./Button.css";

// const Button = ({ text }) => {
// return <button className="primary-btn">{text}</button>;
// };

// export default Button;



import "./Button.css";

const Button = ({ text, onClick, type = "button" }) => {
  return (
    <button
      className="primary-btn"
      type={type}
      onClick={onClick}
    >
      {text}
    </button>
  );
};

export default Button;
