import "./ActionCard.css";

const ActionCard = ({ title, onClick }) => {
  return (
    <div className="action-card" onClick={onClick}>
      <h4>{title}</h4>
    </div>
  );
};

export default ActionCard;
