
// import { useState } from "react";
// import "./styles/global.css";
// import "./styles/variables.css";
// import Login from "./pages/Login/Login";
// import Dashboard from "./pages/Dashboard/Dashboard";

// function App() {
// const [isLoggedIn, setIsLoggedIn] = useState(
//    localStorage.getItem("isSuperAdmin") === "true"
// );

//  if (isLoggedIn) {
//     return (
//      <div style={{ textAlign: "center", marginTop: "50px" }}>
//       <h2>Super Admin is logged in </h2>

//        <button
//         onClick={() => {
//            localStorage.removeItem("isSuperAdmin");
//            localStorage.removeItem("basicAuth");
//            setIsLoggedIn(false);
//         }}
//         >
//           Logout
//       </button>

//       </div>
//     );


//   }

  // return <Login setIsLoggedIn={setIsLoggedIn} />;

//   function App() {
//   const [isLoggedIn, setIsLoggedIn] = useState(
//     localStorage.getItem("isSuperAdmin") === "true"
//   );

//    console.log("IS LOGGED IN:", isLoggedIn);

//   return (
//     <>
//       {isLoggedIn ? (
//         <Dashboard setIsLoggedIn={setIsLoggedIn} />
//       ) : (
//         <Login setIsLoggedIn={setIsLoggedIn} />
//       )}
//     </>
//   );
// }
 

// export default App;




import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login/Login";
import Dashboard from "./pages/Dashboard/Dashboard";
import Schema from "./pages/Schema/Schema";

function App() {
  const isLoggedIn = localStorage.getItem("isSuperAdmin") === "true";

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Login />} />

        <Route
          path="/dashboard"
          element={isLoggedIn ? <Dashboard /> : <Navigate to="/" />}
        />

        <Route
          path="/schema"
          element={isLoggedIn ? <Schema /> : <Navigate to="/" />}
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

